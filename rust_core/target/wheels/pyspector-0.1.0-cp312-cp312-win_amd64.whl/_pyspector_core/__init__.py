from ._pyspector_core import *

__doc__ = _pyspector_core.__doc__
if hasattr(_pyspector_core, "__all__"):
    __all__ = _pyspector_core.__all__